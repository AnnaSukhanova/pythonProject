import sys

from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow


class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('002.ui', self)
        self.stones = 0
        self.pushButton.clicked.connect(self.run)
        self.pushButton_2.clicked.connect(self.run2)

    def run(self):
        self.stones += int(self.lineEdit.text())
        self.lcdNumber.display(self.stones)

    def run2(self):
        if 0 < int(self.lineEdit_2.text()) <= 3:
            self.stones = int(self.stones) - int(self.lineEdit_2.text())
            self.lcdNumber.display(self.stones)
            self.listWidget.addItem(f'Игрок взял - {self.lineEdit_2.text()}')
            if self.stones > 0:
                MyWidget.tak(self)
            else:
                self.label_3.setText('Победа игрока!')
        else:
            self.listWidget.addItem('Неверно введено количество камней')

    def tak(self):
        if self.stones % 4 == 0:
            take = 2
        else:
            take = self.stones % 4
        self.stones -= take
        self.listWidget.addItem(f'ИИ взял - {take}')
        self.lcdNumber.display(self.stones)
        if self.stones == 0:
            self.label_3.setText('Победа компьютера!')



if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
