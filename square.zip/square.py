import sys
sys.excepthook = lambda *a: sys.__excepthook__(*a)
from PyQt5.QtGui import QPainter, QColor
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget





class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('Квадрат-объектив — 1.ui', self)

        self.flag = False
        self.pushButton.clicked.connect(self.draw)

    def draw(self):
        self.side = float(self.lineEdit.text())
        self.side = float(self.lineEdit.text())
        self.coeff = float(self.lineEdit_2.text())
        self.n = int(self.lineEdit_3.text())
        self.flag = True
        self.update()

    def paintEvent(self, event):
        if self.flag:
            qp = QPainter()
            qp.begin(self)
            qp.setPen(QColor(250, 0, 0))
            self.x, self.y = 200, 200
            original_side = self.side
            for _ in range(self.n):
                self.drawSquare(qp)
                DELTA = (self.side * (1 - self.coeff)) / 2
                self.side *= self.coeff
                self.x += DELTA
                self.y += DELTA
            qp.end()
            self.side = original_side

    def drawSquare(self, qp):
        self.x, self.y, self.side = int(self.x), int(self.y), int(self.side)
        qp.drawLine(self.x, self.y, self.x + self.side, self.y)
        qp.drawLine(self.x + self.side, self.y, self.x + self.side, self.y + self.side)
        qp.drawLine(self.x + self.side, self.y + self.side, self.x, self.y + self.side)
        qp.drawLine(self.x, self.y + self.side, self.x, self.y)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec())
